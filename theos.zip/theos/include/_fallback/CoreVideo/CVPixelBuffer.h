#ifndef __COREVIDEO_CVPIXELBUFFER_H__
#define __COREVIDEO_CVPIXELBUFFER_H__ 1
#define CVPIXELBUFFER_FALLBACK 1

typedef int32_t CVReturn;
typedef struct __CVPixelBuffer *CVPixelBufferRef;

#endif
