#ifndef _IOSURFACE_API_H
#define _IOSURFACE_API_H 1
#define IOSURFACE_API_FALLBACK 1

// Allow compilation of most projects even if non-free header is missing
typedef struct __IOSurface *IOSurfaceRef;
typedef unsigned int IOSurfaceID;

#endif
